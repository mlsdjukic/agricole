package hr.zaba.accounts.services;

import hr.zaba.accounts.dto.Account;
import hr.zaba.accounts.dto.AccountMapper;
import hr.zaba.accounts.entities.AccountEntity;
import hr.zaba.accounts.repositories.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
@Service
public class AccountService {

    private final AccountRepository accountRepository;
    private  final AccountMapper accountMapper;
    private final PasswordEncoder passwordEncoder;

    public Mono<Account> createAccount(Account account) {
        AccountEntity accountEntity = accountMapper.toEntity(account);
        accountEntity.setPassword("{bcrypt}" + passwordEncoder.encode(account.getPassword()));
        return accountRepository.save(accountEntity)
                .map(accountMapper::toDTO);
    }

    public Mono<Account> getAccountByUsername(String username) {
        return accountRepository.findByUsername(username)
                .map(accountMapper::toDTO);
    }

    public Flux<Account> getAllAccounts() {
        return accountRepository.findAll()
                .map(accountMapper::toDTO);
    }

    public Mono<Account> getAccountById(String id) {
        return accountRepository.findById(id)
                .map(accountMapper::toDTO);

    }

    public Mono<Account> updateAccount(String id, Account updatedDTO) {
        return accountRepository.findById(id)
                .flatMap(existingAccount -> {
                    existingAccount.setUsername(updatedDTO.getUsername());
                    existingAccount.setPassword("{bcrypt}" + passwordEncoder.encode(updatedDTO.getPassword()));
                    return accountRepository.save(existingAccount);
                })
                .map(accountMapper::toDTO);
    }

    public Mono<Void> deleteAccount(String id) {
        return accountRepository.deleteById(id);
    }
}
