package hr.zaba.accounts.rules;


public interface Rule {
    void execute(Object data);
}
