package hr.zaba.accounts.repositories;

import hr.zaba.accounts.entities.AlarmClassEntity;
import hr.zaba.accounts.entities.AlarmEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface AlarmClassRepository extends ReactiveCrudRepository<AlarmClassEntity, Long> {
}
