package hr.zaba.accounts.dto;

import hr.zaba.accounts.entities.AlarmClassEntity;
import hr.zaba.accounts.entities.AlarmEntity;
import hr.zaba.accounts.entities.AlarmTypeEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AlarmWithTypeAndClass {
    private AlarmEntity alarm;
    private AlarmTypeEntity type;
    private AlarmClassEntity alarmClass;

}
