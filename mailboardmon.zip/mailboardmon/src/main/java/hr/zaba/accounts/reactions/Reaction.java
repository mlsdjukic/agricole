package hr.zaba.accounts.reactions;

import hr.zaba.accounts.dto.Notification;

public interface Reaction {
    Long getRuleId();
    void execute(Notification notification);
}
