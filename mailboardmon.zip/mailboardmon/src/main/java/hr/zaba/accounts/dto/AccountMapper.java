package hr.zaba.accounts.dto;

import hr.zaba.accounts.entities.AccountEntity;
import org.springframework.stereotype.Component;

@Component
public class AccountMapper {

    public AccountEntity toEntity(Account dto) {
        AccountEntity entity = new AccountEntity();
        entity.setUsername(dto.getUsername());
        entity.setPassword(dto.getPassword());
        return entity;
    }

    public Account toDTO(AccountEntity entity) {
        Account dto = new Account();
        dto.setId(entity.getId());
        dto.setUsername(entity.getUsername());
        //dto.setPassword(entity.getPassword());
        return dto;
    }
}
