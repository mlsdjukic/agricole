package hr.zaba.accounts.exceptions;

public class RuleProcessingException extends RuntimeException {
    public RuleProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}