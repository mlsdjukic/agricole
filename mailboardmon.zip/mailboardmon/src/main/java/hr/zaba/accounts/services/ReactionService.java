package hr.zaba.accounts.services;


import hr.zaba.accounts.entities.ReactionEntity;
import hr.zaba.accounts.repositories.ReactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
@Transactional
public class ReactionService {

    private final ReactionRepository reactionRepository;

    @Autowired
    public ReactionService(ReactionRepository reactionRepository) {
        this.reactionRepository = reactionRepository;
    }

    public Flux<ReactionEntity> saveAll(List<ReactionEntity> reactionEntities) {
        return reactionRepository.saveAll(reactionEntities)
                .onErrorResume(ex -> Flux.error(new RuntimeException("Error saving reactions", ex))  // Propagate the error up
                );
    }

    public Flux<ReactionEntity> findByRuleId(Long ruleId) {
        return reactionRepository.findByRuleId(ruleId)
                .onErrorResume(ex -> Mono.error(new IllegalArgumentException("No rule with this id", ex)));
    }

    public Mono<Void> deleteByRuleId(Long ruleId) {
        return reactionRepository.deleteByRuleId(ruleId)
                .onErrorResume(ex -> Mono.error(new IllegalArgumentException("No rule with this id", ex)));

    }
}
