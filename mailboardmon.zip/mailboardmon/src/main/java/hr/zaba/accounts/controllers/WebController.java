package hr.zaba.accounts.controllers;

import hr.zaba.accounts.dto.AlarmResponse;
import hr.zaba.accounts.services.AlarmService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/mailboardmon/")
public class WebController {

    private final AlarmService alarmService;

    public WebController(AlarmService alarmService) {
        this.alarmService = alarmService;
    }

    @GetMapping("/")
    public String index(Model model) {
        List<Alarm> alarms = new ArrayList<>();
        alarmService.getAll().collectList()
                .map(list -> {
                    // use list here
                    alarms.addAll(list);
                    return list;
                }).subscribe(); // or cache / blocking call

        model.addAttribute("alarms", alarms);
        return "ui/index";  // thymeleaf template ui/index.html
    }
    @GetMapping("/settings")
    public String settings(Model model) {
        return "ui/settings";  // thymeleaf template ui/index.html
    }
    @GetMapping("/job")
    public String job(Model model) {
        return "ui/job";  // thymeleaf template ui/index.html
    }

}
