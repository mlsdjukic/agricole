document.addEventListener("DOMContentLoaded", function () {
  const el = document.getElementById("alarm-list");
  if (el) {
    el.innerHTML = "<p>Static JS says: Hello from demo.js!</p>";
  }
});
