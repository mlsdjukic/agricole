-- Create type table
CREATE TABLE alarm_type (
    id bigint IDENTITY(1,1) NOT NULL,
    name nvarchar(100) NOT NULL,
    metadata nvarchar(max) NOT NULL,
    CONSTRAINT alarm_type_pkey PRIMARY KEY (id)
);

-- Create class table
CREATE TABLE alarm_class (
    id bigint IDENTITY(1,1) NOT NULL,
    name nvarchar(100) NOT NULL,
    metadata nvarchar(max) NOT NULL,
    CONSTRAINT alarm_class_pkey PRIMARY KEY (id)
);

-- Alter alarms table to add type_id and class_id
ALTER TABLE alarms
ADD
    type_id bigint NULL DEFAULT NULL,
    class_id bigint NULL DEFAULT NULL,
    CONSTRAINT fk_alarm_type FOREIGN KEY (type_id) REFERENCES alarm_type(id),
    CONSTRAINT fk_alarm_class FOREIGN KEY (class_id) REFERENCES alarm_class(id);
