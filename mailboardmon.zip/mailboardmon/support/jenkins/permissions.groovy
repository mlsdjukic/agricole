permissions = [
        'hudson.model.Item.Build:${sovaDevOpsFunction}',
        'hudson.model.Item.Cancel:${sovaDevOpsFunction}',
        'hudson.model.Item.Configure:${sovaDevOpsFunction}',
        'hudson.model.Item.Discover:${sovaDevOpsFunction}',
        'hudson.model.Item.Read:${sovaDevOpsFunction}',
        'hudson.model.Item.Workspace:${sovaDevOpsFunction}',
        'hudson.model.Run.Delete:${sovaDevOpsFunction}',
        'hudson.model.Run.Replay:${sovaDevOpsFunction}',
        'hudson.model.Run.Update:${sovaDevOpsFunction}',
        'hudson.model.Item.Build:${sovaDevOpsFunction}',
        'hudson.scm.SCM.Tag:${sovaDevOpsFunction}'
]
