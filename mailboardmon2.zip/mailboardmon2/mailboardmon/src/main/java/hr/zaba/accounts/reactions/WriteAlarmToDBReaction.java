package hr.zaba.accounts.reactions;

import hr.zaba.accounts.components.ApplicationContextProvider;
import hr.zaba.accounts.dto.AlarmRequest;
import hr.zaba.accounts.dto.Notification;
import hr.zaba.accounts.services.AlarmService;

public class WriteAlarmToDBReaction implements Reaction{

    private final Long ruleId;

    private final AlarmService alarmService;

    public WriteAlarmToDBReaction(Long ruleId) {
        this.ruleId = ruleId;
        this.alarmService = ApplicationContextProvider.getApplicationContext().getBean(AlarmService.class);
    }

    @Override
    public Long getRuleId() {
        return this.ruleId;
    }

    @Override
    public void execute(Notification notification) {
        alarmService.save(new AlarmRequest(notification.getRuleId(), notification.getMessage()))
                .subscribe();
    }
}
